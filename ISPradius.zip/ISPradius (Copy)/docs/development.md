# ISPradius Development Guide

## Getting Started

1. **Clone the repository**
   ```bash
   git clone https://github.com/devworklife-collab/ISPradius.git
   cd ISPradius
   ```

2. **Install dependencies**
   ```bash
   # Backend
   cd backend
   npm install

   # Frontend
   cd ../frontend
   npm install
   ```

3. **Set up environment variables**
   ```bash
   cp .env.example .env
   # Edit .env with your configuration
   ```

4. **Start PostgreSQL and Redis**
   ```bash
   # Using Docker
   docker run -d --name postgres -p 5432:5432 -e POSTGRES_DB=ispradius -e POSTGRES_USER=ispradius -e POSTGRES_PASSWORD=password postgres:15
   docker run -d --name redis -p 6379:6379 redis:7-alpine
   ```

5. **Run database migrations**
   ```bash
   # Using a PostgreSQL client
   psql -U ispradius -d ispradius -f database/migrations/001_initial.sql
   psql -U ispradius -d ispradius -f database/seeds/001_initial_data.sql
   ```

6. **Start the backend**
   ```bash
   cd backend
   npm run start:dev
   ```

7. **Start the frontend**
   ```bash
   cd frontend
   npm run dev
   ```

## Project Structure

```
ISPradius/
├── backend/                 # NestJS API server
│   ├── src/
│   │   ├── modules/         # Feature modules
│   │   │   ├── auth/        # Authentication module
│   │   │   └── customers/   # Customer management
│   │   ├── app.module.ts    # Main application module
│   │   └── main.ts          # Application entry point
│   ├── package.json
│   └── tsconfig.json
├── frontend/                # Next.js React application
│   ├── app/                 # Next.js 13+ app directory
│   ├── components/          # Reusable React components
│   ├── package.json
│   └── tailwind.config.js
├── database/                # Database migrations and seeds
├── infrastructure/          # Docker, Kubernetes configs
├── docs/                    # Documentation
└── README.md
```

## Development Workflow

### Adding New Features

1. **Backend**: Create a new module in `backend/src/modules/`
2. **Database**: Add migrations in `database/migrations/`
3. **Frontend**: Add pages in `frontend/app/` and components in `frontend/components/`
4. **API**: Update GraphQL schemas and resolvers

### Code Quality

- Use TypeScript for type safety
- Follow ESLint rules
- Write unit tests for business logic
- Use meaningful commit messages

### Testing

```bash
# Backend tests
cd backend
npm run test

# Frontend tests
cd frontend
npm run test
```

## API Endpoints

- **GraphQL**: `http://localhost:3000/graphql`
- **REST**: `http://localhost:3000/api/*`

## Default Credentials

- **Email**: admin@ispradius.com
- **Password**: admin123

## Contributing

1. Create a feature branch
2. Make your changes
3. Write tests
4. Submit a pull request

## Support

For questions or issues, please create an issue in the GitHub repository.