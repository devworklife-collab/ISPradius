# ISPradius Deployment Guide

## Prerequisites

- Docker & Docker Compose
- Kubernetes cluster (optional)
- Domain name with SSL certificate

## Quick Start with Docker Compose

1. Clone the repository
2. Copy `.env.example` to `.env` and configure
3. Run `docker-compose up -d`

## Environment Variables

```env
# Database
DB_HOST=postgres
DB_PORT=5432
DB_USERNAME=ispradius
DB_PASSWORD=password
DB_NAME=ispradius

# Redis
REDIS_HOST=redis
REDIS_PORT=6379

# JWT
JWT_SECRET=your-secret-key

# Email
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=your-email@gmail.com
SMTP_PASS=your-password

# Payment Gateways
STRIPE_SECRET_KEY=sk_test_...
PAYPAL_CLIENT_ID=...
```

## Docker Compose Services

- **frontend**: Next.js application
- **backend**: NestJS API server
- **postgres**: PostgreSQL database
- **redis**: Redis cache and queue
- **nginx**: Reverse proxy and load balancer
- **freeradius**: RADIUS server

## Kubernetes Deployment

1. Install Helm
2. Add the ISPradius chart repository
3. Install with `helm install ispradius ./infrastructure/kubernetes`

## SSL Configuration

Use Let's Encrypt for automatic SSL certificates:

```nginx
server {
    listen 443 ssl http2;
    server_name your-domain.com;

    ssl_certificate /etc/letsencrypt/live/your-domain.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/your-domain.com/privkey.pem;

    location / {
        proxy_pass http://frontend:3000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }

    location /api {
        proxy_pass http://backend:3000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }
}
```

## Monitoring Setup

1. Install Prometheus and Grafana
2. Import the ISPradius dashboards
3. Configure alerting rules

## Backup Strategy

- Daily database backups
- File system snapshots
- Offsite backup storage

## Scaling

- Horizontal Pod Autoscaling in Kubernetes
- Database read replicas
- CDN for static assets