# ISPradius API Documentation

## Overview

ISPradius provides both REST and GraphQL APIs for integration.

## Authentication

All API requests require authentication using JWT tokens.

```
Authorization: Bearer <token>
```

## GraphQL Endpoint

```
POST /graphql
```

## REST Endpoints

### Authentication

- `POST /auth/login` - User login
- `POST /auth/register` - User registration
- `GET /auth/profile` - Get user profile

### Customers

- `GET /customers` - List customers
- `POST /customers` - Create customer
- `GET /customers/:id` - Get customer
- `PUT /customers/:id` - Update customer
- `DELETE /customers/:id` - Delete customer

### Billing

- `GET /billing/invoices` - List invoices
- `POST /billing/invoices` - Create invoice
- `GET /billing/invoices/:id` - Get invoice
- `POST /billing/payments` - Process payment

### Network

- `GET /network/devices` - List devices
- `POST /network/devices` - Add device
- `GET /network/sessions` - Active sessions

## Webhooks

### Payment Webhooks

Supported gateways: Stripe, PayPal, Razorpay, bKash, Nagad, Rocket

```
POST /webhooks/payments
```

### RADIUS Accounting

```
POST /webhooks/radius/accounting
```

## Rate Limiting

- 1000 requests per hour for authenticated users
- 100 requests per hour for unauthenticated requests

## Error Handling

All errors return JSON with the following structure:

```json
{
  "error": "Error message",
  "code": "ERROR_CODE",
  "statusCode": 400
}
```