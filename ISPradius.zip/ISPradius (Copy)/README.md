# ISPradius

A complete ISP Operations Platform capable of running a real Internet Service Provider with thousands of customers.

## Features

- **ISP Billing**: Recurring, usage, prepaid, postpaid billing with invoice generation
- **Customer CRM**: Full customer management with profiles, history, and states
- **Network Automation**: Integration with MikroTik, Cisco, Ubiquiti devices
- **Device Monitoring**: SNMP, ICMP monitoring with health dashboards
- **Ticketing System**: Built-in helpdesk for customer support
- **Analytics & Reporting**: Revenue, customer growth, network usage reports
- **Accounting**: Income/expense tracking, P&L reports
- **Multi-Branch/Reseller Support**: Branch-based management and permissions

## Technical Stack

- **Backend**: Node.js with NestJS, TypeScript, REST API + GraphQL, WebSockets
- **Frontend**: Next.js with React, TailwindCSS, admin dashboard
- **Database**: PostgreSQL primary, Redis for cache and queues
- **Queue**: BullMQ or RabbitMQ
- **Infrastructure**: Docker, Nginx, Kubernetes-ready
- **Monitoring**: Prometheus, Grafana

## Architecture

Modular microservice architecture with independent services:
- Authentication Service
- Customer Service
- Billing Engine
- Network Device Service
- RADIUS Integration Service
- Ticketing System
- Notification Service
- Monitoring Service
- Reporting Service
- Accounting Service
- Payment Gateway Service

Event-driven architecture with events like InvoiceCreated, PaymentReceived, etc.

## Getting Started

### Prerequisites

- Node.js 18+
- PostgreSQL 15+
- Redis 7+
- Docker & Docker Compose

### Installation

1. Clone the repository
2. Install dependencies: `npm install`
3. Set up environment variables
4. Run database migrations
5. Start the services with Docker Compose

### Development

See [docs/development.md](docs/development.md) for detailed setup.

## Documentation

- [Architecture](docs/architecture.md)
- [API Documentation](docs/api.md)
- [Deployment Guide](docs/deployment.md)

## License

Open-source, MIT License