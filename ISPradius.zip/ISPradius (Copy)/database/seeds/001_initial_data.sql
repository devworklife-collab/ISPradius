-- Seed data for ISPradius

-- Insert default roles
INSERT INTO "role" ("id", "name", "description") VALUES
('550e8400-e29b-41d4-a716-446655440000', 'super_admin', 'Super Administrator with full access'),
('550e8400-e29b-41d4-a716-446655440001', 'isp_admin', 'ISP Administrator'),
('550e8400-e29b-41d4-a716-446655440002', 'billing_manager', 'Billing Manager'),
('550e8400-e29b-41d4-a716-446655440003', 'support_agent', 'Support Agent'),
('550e8400-e29b-41d4-a716-446655440004', 'network_engineer', 'Network Engineer'),
('550e8400-e29b-41d4-a716-446655440005', 'technician', 'Technician'),
('550e8400-e29b-41d4-a716-446655440006', 'read_only', 'Read Only User');

-- Insert default permissions
INSERT INTO "permission" ("id", "name", "description", "module") VALUES
('660e8400-e29b-41d4-a716-446655440000', 'customers.read', 'View customers', 'customers'),
('660e8400-e29b-41d4-a716-446655440001', 'customers.write', 'Create/Edit customers', 'customers'),
('660e8400-e29b-41d4-a716-446655440002', 'billing.read', 'View billing', 'billing'),
('660e8400-e29b-41d4-a716-446655440003', 'billing.write', 'Create/Edit billing', 'billing'),
('660e8400-e29b-41d4-a716-446655440004', 'network.read', 'View network', 'network'),
('660e8400-e29b-41d4-a716-446655440005', 'network.write', 'Manage network', 'network'),
('660e8400-e29b-41d4-a716-446655440006', 'tickets.read', 'View tickets', 'tickets'),
('660e8400-e29b-41d4-a716-446655440007', 'tickets.write', 'Manage tickets', 'tickets');

-- Insert default user (password: admin123)
INSERT INTO "user" ("id", "email", "password", "firstName", "lastName", "roleId") VALUES
('770e8400-e29b-41d4-a716-446655440000', 'admin@ispradius.com', '$2b$10$8K3VZvB8Q8VzKvB8Q8VzKvB8Q8VzKvB8Q8VzKvB8Q8VzKvB8Q8VzKv', 'Super', 'Admin', '550e8400-e29b-41d4-a716-446655440000');

-- Insert sample branch
INSERT INTO "branch" ("id", "name", "address") VALUES
('880e8400-e29b-41d4-a716-446655440000', 'Main Branch', '123 Main Street, City, Country');

-- Insert sample service plans
INSERT INTO "service_plan" ("id", "name", "description", "price", "speedLimit", "dataQuota") VALUES
('990e8400-e29b-41d4-a716-446655440000', 'Basic Plan', 'Basic internet plan', 29.99, 10, 107374182400),
('990e8400-e29b-41d4-a716-446655440001', 'Premium Plan', 'Premium internet plan', 49.99, 50, 536870912000);