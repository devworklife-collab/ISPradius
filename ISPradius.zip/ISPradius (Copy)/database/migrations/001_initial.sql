-- Initial database schema for ISPradius

-- Users and Authentication
CREATE TABLE "role" (
    "id" uuid NOT NULL DEFAULT uuid_generate_v4(),
    "name" varchar NOT NULL,
    "description" varchar NOT NULL,
    "createdAt" TIMESTAMP NOT NULL DEFAULT now(),
    "updatedAt" TIMESTAMP NOT NULL DEFAULT now(),
    CONSTRAINT "PK_role" PRIMARY KEY ("id"),
    CONSTRAINT "UQ_role_name" UNIQUE ("name")
);

CREATE TABLE "permission" (
    "id" uuid NOT NULL DEFAULT uuid_generate_v4(),
    "name" varchar NOT NULL,
    "description" varchar NOT NULL,
    "module" varchar NOT NULL,
    "createdAt" TIMESTAMP NOT NULL DEFAULT now(),
    "updatedAt" TIMESTAMP NOT NULL DEFAULT now(),
    CONSTRAINT "PK_permission" PRIMARY KEY ("id"),
    CONSTRAINT "UQ_permission_name" UNIQUE ("name")
);

CREATE TABLE "role_permissions_permission" (
    "roleId" uuid NOT NULL,
    "permissionId" uuid NOT NULL,
    CONSTRAINT "PK_role_permissions" PRIMARY KEY ("roleId", "permissionId")
);

CREATE TABLE "user" (
    "id" uuid NOT NULL DEFAULT uuid_generate_v4(),
    "email" varchar NOT NULL,
    "password" varchar NOT NULL,
    "firstName" varchar NOT NULL,
    "lastName" varchar NOT NULL,
    "phone" varchar,
    "status" varchar NOT NULL DEFAULT 'active',
    "twoFactorSecret" varchar,
    "isTwoFactorEnabled" boolean NOT NULL DEFAULT false,
    "roleId" uuid,
    "createdAt" TIMESTAMP NOT NULL DEFAULT now(),
    "updatedAt" TIMESTAMP NOT NULL DEFAULT now(),
    CONSTRAINT "PK_user" PRIMARY KEY ("id"),
    CONSTRAINT "UQ_user_email" UNIQUE ("email")
);

-- Customers
CREATE TABLE "branch" (
    "id" uuid NOT NULL DEFAULT uuid_generate_v4(),
    "name" varchar NOT NULL,
    "address" text,
    "phone" varchar,
    "email" varchar,
    "createdAt" TIMESTAMP NOT NULL DEFAULT now(),
    "updatedAt" TIMESTAMP NOT NULL DEFAULT now(),
    CONSTRAINT "PK_branch" PRIMARY KEY ("id")
);

CREATE TABLE "service_plan" (
    "id" uuid NOT NULL DEFAULT uuid_generate_v4(),
    "name" varchar NOT NULL,
    "description" text NOT NULL,
    "price" decimal(10,2) NOT NULL,
    "billingCycle" varchar NOT NULL DEFAULT 'monthly',
    "type" varchar NOT NULL DEFAULT 'residential',
    "speedLimit" integer,
    "dataQuota" bigint,
    "createdAt" TIMESTAMP NOT NULL DEFAULT now(),
    "updatedAt" TIMESTAMP NOT NULL DEFAULT now(),
    CONSTRAINT "PK_service_plan" PRIMARY KEY ("id")
);

CREATE TABLE "customer" (
    "id" uuid NOT NULL DEFAULT uuid_generate_v4(),
    "firstName" varchar NOT NULL,
    "lastName" varchar NOT NULL,
    "email" varchar NOT NULL,
    "phone" varchar,
    "address" text,
    "status" varchar NOT NULL DEFAULT 'active',
    "branchId" uuid,
    "servicePlanId" uuid,
    "registrationDate" date,
    "expiryDate" date,
    "createdAt" TIMESTAMP NOT NULL DEFAULT now(),
    "updatedAt" TIMESTAMP NOT NULL DEFAULT now(),
    CONSTRAINT "PK_customer" PRIMARY KEY ("id"),
    CONSTRAINT "UQ_customer_email" UNIQUE ("email")
);

-- Foreign Key Constraints
ALTER TABLE "role_permissions_permission" ADD CONSTRAINT "FK_role_permissions_role" FOREIGN KEY ("roleId") REFERENCES "role"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "role_permissions_permission" ADD CONSTRAINT "FK_role_permissions_permission" FOREIGN KEY ("permissionId") REFERENCES "permission"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "user" ADD CONSTRAINT "FK_user_role" FOREIGN KEY ("roleId") REFERENCES "role"("id") ON DELETE SET NULL ON UPDATE CASCADE;
ALTER TABLE "customer" ADD CONSTRAINT "FK_customer_branch" FOREIGN KEY ("branchId") REFERENCES "branch"("id") ON DELETE SET NULL ON UPDATE CASCADE;
ALTER TABLE "customer" ADD CONSTRAINT "FK_customer_service_plan" FOREIGN KEY ("servicePlanId") REFERENCES "service_plan"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- Indexes
CREATE INDEX "IDX_user_email" ON "user" ("email");
CREATE INDEX "IDX_customer_email" ON "customer" ("email");
CREATE INDEX "IDX_customer_status" ON "customer" ("status");